package com.infotech.app.dao;

import java.util.List;

import com.infotech.app.entities.Topic;

public interface TopicDAO {
	public abstract List<Topic> getAllTopics();
}

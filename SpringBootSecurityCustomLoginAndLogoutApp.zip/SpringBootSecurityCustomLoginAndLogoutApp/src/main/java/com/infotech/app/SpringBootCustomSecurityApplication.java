package com.infotech.app;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootCustomSecurityApplication {  
	public static void main(String[] args) {
		SpringApplication.run(SpringBootCustomSecurityApplication.class, args);
    }       
}            